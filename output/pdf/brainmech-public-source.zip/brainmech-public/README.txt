BrainMech public preprint source

Build: pdflatex -no-shell-escape brainmech-public.tex (run twice).

Authors are listed in the order supplied by Jiaqi Wu: Jiaqi Wu, Shuheng Cao, Tingting Dan, Ziquan Wei, Zhixuan Zhou, Guorong Wu.
Affiliations were not supplied and are omitted.

Production changes:
- Compiled using the official template in preprint mode.
- Preserved the provided research text, formulas, and numerical results.
- Recovered 12 figure regions as raster images from the supplied PDF.
- Reconstructed all 43 bibliography entries from the supplied PDF (references.tex).
- Omitted the submission checklist and review-specific identifiers/footers.
- Removed negative figure spacing that caused overlap with tightly cropped figures.
- Changed the two short ablation wrapped figures to normal floats.
- Removed the dangling "in Eq.\ref{eq:stab_main}" cross-reference; no matching equation label existed in the supplied source. The surrounding sentence and mathematical expressions are unchanged.

The bibliography entries were recovered, not independently fact-checked.
